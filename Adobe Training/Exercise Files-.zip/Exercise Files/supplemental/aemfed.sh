#!/bin/bash -x


aemfed -t http://admin:admin@localhost:4502 -w ui.apps/src/main/content/jcr_root/